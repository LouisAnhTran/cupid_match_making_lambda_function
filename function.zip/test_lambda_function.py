import json
from lambda_function import lambda_handler

test_event = {
    "username": "louis",
    "gender": "Male",
    "gender_preferences": "Female"
}

response = lambda_handler(test_event, None)
print(response)
